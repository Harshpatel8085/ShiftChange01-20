const DEMO = {
    BLANK_LINK: "#!",
};

export default DEMO;